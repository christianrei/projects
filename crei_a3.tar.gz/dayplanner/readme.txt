Christian Rei, 0832859, Assignment 3 OOP, Friday, November 28, 2014

How to run

Once all 7 classes are downloaded and in the same directory/project, 
the main project in netbeans must be set to Assignment 2. The dayplanner
class has main in it and that is what will be run. When you click the 
green play button on netbeans the programs will compile and it will 
start to run at the bottom. The program will display a GUI and inform
the user on how to use it. The file features from assignment 2 have
been commented out due to that not being the focus of this assignment.
Everything must be done through the GUI. 

No known limitations.
